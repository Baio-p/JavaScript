import ventanas.VentanaPrincipal;

/**
 * @author <a href="https://github.com/Baio-p">Benjamim</a>
 * @version 1.0 14/12/22
 */
public class App {
    public static void main(String[] args) {

        //creamos el objeto para invocarlo en nuestro main.
        VentanaPrincipal calculadora = new VentanaPrincipal("Calculadora");

        //definimos la interfaz visible.
        calculadora.setVisible(true);

        
        
    }
} 
